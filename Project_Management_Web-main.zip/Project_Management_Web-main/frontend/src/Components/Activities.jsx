import React from 'react'

function Activities() {
  return (
    <div>
      <h1>Acitivity</h1>
    </div>
  )
}

export default Activities
